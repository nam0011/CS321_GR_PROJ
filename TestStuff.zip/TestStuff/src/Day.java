public class Day {
    private int year;
    private int month;
    private int day;

    public Day(){
    year = 1970;
    month = 1;
    day = 1;

    }

    public void setDate(int year, int month, int date){
       this.year = year;
       this.month = month;
       this.day = date;
    }

    public Day plusday(int n){
        return this;
    }

    public int daysfrom(Day day2){
        return 5;
    }
    public int daysto(Day day2){
        return 5;
    }
}
