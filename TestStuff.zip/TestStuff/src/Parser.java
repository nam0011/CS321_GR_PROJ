//import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author Joseph Lambo
 * CS321-03
 * Parser Object Class
 */


/**
 * Public class that Parses the Ingredient json file and stores Ingredients in the Ingredient dictionary.
 * */
public class Parser {
    public ArrayList<IngredientItem> Ingredients = new ArrayList();
    /**
     * This takes in a word read from the json file, deletes the non letter characters, and returns the original string.
     * @param input is the string consisting of letters and non-letter characters.
     * @return This returns the string without non-letter characters.
     * */
    private String trueString(String input){
      String returnval = "";
      for(int i = 0;i<input.length();i++){
          if (Character.isLetter(input.charAt(i))){
              returnval = returnval.concat(Character.toString(input.charAt(i)));
          }
      }
      return returnval;
    }
    /**
     * This takes in a word read from the json file, deletes the non digit characters, and returns the double in question.
     * @param input is the string consisting of letters and non-letter characters.
     * @return This returns the double without non-digit characters.
     * */
    private double trueInt(String input){
        String returnval = "";
        for(int i = 0;i<input.length();i++){
            Character inputchar = input.charAt(i);
            if (Character.isDigit(inputchar)||inputchar.equals('.')){
                returnval = returnval.concat(Character.toString(input.charAt(i)));
            }
        }
        double finalval = Double.parseDouble(returnval);
        return finalval;
    }
    /**
     * This takes in the Scanner as it is being read and returns the string before occurrence of the ',' character.
     * This removes all non letter characters in the string it returns.
     * @param readline is the Scanner variable that contains a line from the json file.
     * @return This returns the string without non-letter characters.
     * */
    private String trueConcatString(Scanner readline){
        String name = "";

        String curword = readline.next();
        Character endcheck = curword.charAt(curword.length()-1);
        char endLimiter = ' ';
        while (!endcheck.equals(endLimiter)) {
            endLimiter = ',';
            endcheck = curword.charAt(curword.length()-1);
            name = name.concat(trueString(curword).concat(" "));
            if (!endcheck.equals(endLimiter)) {
                curword = readline.next();
            }

        }
        name = name.substring(0,name.length()-1); //Delete extra space at the end
        return name;
    }
    /**
     * This reads the json file and loads the inventory based on the values being read.
     * */
    public void LoadInventory() throws IOException {
        String name2 = "ingredients.json";
        File readfile = new File(name2);
        Scanner readIngredients = new Scanner(readfile);
        //Scanner readRecipes = new Scanner("recipes.json");
        String curline; //Read current line
        while (readIngredients.hasNextLine()){
        curline = readIngredients.nextLine();
        if (curline.length()>14) { //Would like to avoid hardcoding but felt this was an easy enough fix for what was a minor problem
            if (curline.charAt(0) == '{') {
                String name = "";
                String type = "";
                double cost = 0;
                double weight = 0;
                double onHand = 0;
                String word;
                String unit = "tbd";
                String ignore;
                String curword;
                Scanner readline = new Scanner(curline);
                while (readline.hasNext()) {
                    word = readline.next();
                    word = trueString(word);
                    switch (word) {
                        case "name":
                            ignore = readline.next();
                            name = trueConcatString(readline);

                            break;
                        case "type":
                            ignore = readline.next();
                            type = trueString(readline.next());
                            break;
                        case "cost":
                            ignore = readline.next();
                            cost = trueInt(readline.next());
                            break;
                        case "weight":
                            ignore = readline.next();
                            weight = trueInt(readline.next());
                            break;
                        case "onHand":
                            ignore = readline.next();
                            onHand = trueInt(readline.next());
                            break;
                    }
                }

                IngredientItem CurIngredient = new IngredientItem(name, type, unit, cost, weight, onHand);
                Ingredients.add(CurIngredient);

            } else {
                System.out.println("s");
            }
        }
        }
    }
    public static void main(String[] args) throws IOException {
    Parser a = new Parser();
    a.LoadInventory();
    System.out.println("done");
    }

}
