package com.company;

import java.io.IOException;

public class Main {

    public static void main(String[] args) throws CloneNotSupportedException {
	// write your code here
        DemoSetup demoSetup = new DemoSetup();




    }


}
